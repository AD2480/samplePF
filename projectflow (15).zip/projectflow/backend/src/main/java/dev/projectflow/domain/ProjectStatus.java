package dev.projectflow.domain;

/** Lifecycle of a project. */
public enum ProjectStatus {
    ACTIVE,
    ON_HOLD,
    COMPLETED,
    ARCHIVED
}
