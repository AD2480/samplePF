package dev.projectflow.config;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/** Swagger UI at /swagger-ui.html with a "Bearer" auth button for the JWT. */
@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI projectFlowOpenApi() {
        return new OpenAPI()
                .info(new Info().title("ProjectFlow API").version("1.0").description("Projects, tasks and the evidence-based review workflow."))
                .components(new Components().addSecuritySchemes("bearer",
                        new SecurityScheme().type(SecurityScheme.Type.HTTP).scheme("bearer").bearerFormat("JWT")))
                .addSecurityItem(new SecurityRequirement().addList("bearer"));
    }
}
