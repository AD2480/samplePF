package dev.projectflow.domain;

/** Reviewer decision on a submission. */
public enum ReviewDecision {
    APPROVED,
    CHANGES_REQUESTED
}
