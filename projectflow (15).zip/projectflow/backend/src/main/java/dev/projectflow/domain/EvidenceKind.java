package dev.projectflow.domain;

/** Type of evidence attached to a submission. */
public enum EvidenceKind {
    REPOSITORY,
    DEPLOYMENT,
    LINK,
    SCREENSHOT,
    FILE
}
