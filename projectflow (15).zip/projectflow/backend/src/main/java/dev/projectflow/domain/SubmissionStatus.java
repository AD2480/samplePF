package dev.projectflow.domain;

/** State of one submitted version. */
public enum SubmissionStatus {
    PENDING,
    APPROVED,
    CHANGES_REQUESTED
}
