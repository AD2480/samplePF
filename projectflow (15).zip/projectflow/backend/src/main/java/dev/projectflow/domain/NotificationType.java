package dev.projectflow.domain;

/** Inbox notification categories. */
public enum NotificationType {
    TASK_ASSIGNED,
    INVITATION,
    SUBMISSION,
    REVIEW_APPROVED,
    CHANGES_REQUESTED,
    COMMENT,
    ROLE_CHANGED,
    PLAN_CHANGED
}
